# HITL Attest

Human-in-the-loop accountability for AI-written code:
**World ID** (one human, one account) + **validation receipts** (who approved which output, no
token) + a **penalty token** minted only when forensics proves a validation wrong: soulbound,
escalating, capped and fading, with three stages (published score, no AI access, banned).

Read `DESIGN.md` for how it works and `AUDIT.md` for the security review.

## Layout

```
src/
  HumanRegistry.sol          World ID enrollment: one human -> one key; key rotation keeps the score
  PermissionRegistry.sol     expiring permissions, presets, repos, policy; reads penalty stage
  ValidationReceipts.sol     receipts at validation (no token), forensics audit, appeals, merge gate
  PenaltyLedger.sol          penalty token (soulbound) + escalating, capped, fading score + stages
  WorldIDVerifier.sol        adapter to the World ID router (swappable)
  interfaces/                IHumanVerifier, IWorldID, IPenalty
  mirrors/ENSRoleMirror.sol  ENSv1 mirror, out of audit scope, to be replaced by ENSv2
  mocks/Mocks.sol            MockWorldID, MockUSD (local only)
test/
  Base.t.sol                 shared fixture
  Receipts.t.sol             auth, receipts, forensics, appeals, audit regressions
  Ledger.t.sol               penalty token, escalation, cap, fade, stages, forgiveness
  LedgerFuzz.t.sol           fuzz + stateful invariants
environments/*.json          policy, receipt windows, penalty rules, repos, presets, fees
orchestrator/                Zone 1 pipeline + end-to-end demo (2 users + forensics/appeals/evaluator)
DESIGN.md                    how it works
AUDIT.md                     security review: findings, fixes, trust assumptions
```

## Run

Requires Foundry (`forge`, `anvil`) and Node 20+.

```bash
forge install foundry-rs/forge-std OpenZeppelin/openzeppelin-contracts@v5.1.0
forge build
forge test                      # 55 tests: unit, fuzz, invariants
cd orchestrator && npm install
node demo.js                    # end-to-end on a local anvil chain
node check-envs.js              # verify all environment presets
```

To use your own environment, copy a file in `environments/` and pass it to the demo:
`node demo.js ../environments/my-env.json`. The demo script assumes repos named
`acme/web` and `acme/payments` and presets `coder`/`reviewer`, so adjust it to match your file.
